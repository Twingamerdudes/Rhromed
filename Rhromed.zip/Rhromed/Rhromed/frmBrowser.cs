﻿using EasyTabs;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rhromed
{
    public partial class frmBrowser : Form
    {
        public bool DarkScreen = false;

        public frmBrowser()
        {
            InitializeComponent();
            var appName = System.Diagnostics.Process.GetCurrentProcess().ProcessName + ".exe";
            using (var Key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", true))
                Key.SetValue(appName, 99999, RegistryValueKind.DWord);
            webBrowser2.Navigate("https://google.com");
            bunifuCards2.Visible = false;

        }

        protected TitleBarTabs ParentTabs
        {
            get
            {
                return (ParentForm as TitleBarTabs);
            }
        }

        
        

        private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            webBrowser1.Text = webBrowser2.Url.AbsoluteUri;
        }

        private void Home_btn_Click(object sender, EventArgs e)
        {
            
            webBrowser2.Navigate("https://google.com");
          
        }

        private void Forward_btn_Click(object sender, EventArgs e)
        {
            if (webBrowser2.CanGoForward) webBrowser2.GoForward();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            if (webBrowser2.CanGoBack) webBrowser2.GoBack();
        }

        private void Refresh_btn_Click(object sender, EventArgs e)
        {
            webBrowser2.Refresh();
        }

        private void webBrowser1_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter && webBrowser1.Text.Trim().Length > 0)
            {
                if (webBrowser1.Text.Contains("."))
                {
                    
                    webBrowser2.Navigate(webBrowser1.Text.Trim());
                    
                }
                else
                {
                    
                    webBrowser2.Navigate("https://google.com/?q=" + webBrowser1.Text.Trim().Replace(" ", "+") + "&t=ho&va=q&ia=web");
                    
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                DarkScreen = true;
            }
            else
            {
                DarkScreen = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(DarkScreen == true)
            {
                bunifuCards1.BackColor = Color.DarkGray;
                bunifuCards2.BackColor = Color.DarkGray;
                bunifuCards3.BackColor = Color.Silver;
                bunifuCards1.color = Color.DarkGray;
                bunifuCards2.color = Color.DarkGray;
                bunifuCards3.color = Color.DarkGray;
                pictureBox6.BackColor = Color.DarkGray;
                webBrowser1.BackColor = Color.Silver;
                webBrowser1.ForeColor = Color.Gray;
            }
            else
            {
                bunifuCards1.BackColor = Color.WhiteSmoke;
                bunifuCards2.BackColor = Color.WhiteSmoke;
                bunifuCards3.BackColor = Color.White;
                bunifuCards1.color = Color.WhiteSmoke;
                bunifuCards2.color = Color.WhiteSmoke;
                bunifuCards3.color = Color.WhiteSmoke;
                pictureBox6.BackColor = Color.WhiteSmoke;
                webBrowser1.BackColor = Color.White;

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            bunifuCards2.Visible = true;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            bunifuCards2.Visible = false;
        }
    }
    
}
